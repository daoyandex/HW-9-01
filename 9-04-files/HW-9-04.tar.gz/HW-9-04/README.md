### ДЗ по 9-04 Reliability


#### 1 Create dir ~/terraform-project/HW-9-04-tf
user@debian:~/terraform-project$ mkdir HW-9-04-tf && cd HW-9-04-tf

#### 2 Инициализируем CLI yc
user@debian:~/terraform-project/HW-9-04-tf$ yc init
Welcome! This command will take you through the configuration process.
Pick desired action:
 [1] Re-initialize this profile 'profile-tf-7-03' with new settings 
 [2] Create a new profile
 [3] Switch to and re-initialize existing profile: 'default'
 [4] Switch to and re-initialize existing profile: 'tf-sa-profile'
Please enter your numeric choice: 2
Enter profile name. Names start with a lower case letter and contain only lower case letters a-z, digits 0-9, and hyphens '-': tf-profile-hw-9-04 
Please go to https://oauth.yandex.ru/authorize?response_type=token&client_id=1a6990aa636648e9b2ef855fa7bec2fb in order to obtain OAuth token.
 
 Please enter OAuth token: 
 y0_AgAAAAB1k72UAATuwQAAAAED3RSNAADMBRh2XShNyrRaGREkNnLUinFffQ

# комментарий: этот токен должен быть установлен в настройках текущей конфигурации yc
# если требуется, его можно переустановить:
yc config set token <>

#  ссылки на ресурсы по авторизации и аутентификации
https://yandex.cloud/ru/docs/iam/operations/compromised-credentials#oauth-reissue
https://yandex.cloud/ru/docs/iam/concepts/authorization/iam-token
https://yandex.cloud/ru/docs/tutorials/infrastructure-management/terraform-quickstart#get-credentials

 You have one cloud available: 'cloud-a-debian' (id = b1gat3mr49cc9tpvs9vo). It is going to be used by default.
Please choose folder to use:
 [1] minikube (id = b1gr4r2q77ug0qrleks2)
 [2] terraform-1 (id = b1gd8knketmmp6gcnkld)
 [3] tf-7-03-task-1 (id = b1gtr8r85q7h762d3u8v)
 [4] Create a new folder
Please enter your numeric choice: 4
Please enter a folder name: hw-9-04
Your current folder has been set to 'hw-9-04' (id = b1gdfeit559f74dcgoj7).
Do you want to configure a default Compute zone? [Y/n] Y

Which zone do you want to use as a profile default?
 [1] ru-central1-a
 [2] ru-central1-b
 [3] ru-central1-c
 [4] ru-central1-d
 [5] Don't set default zone
Please enter your numeric choice: 1

#### 3 Создадим сервисный аккаунт
user@debian:~/terraform-project/HW-9-04-tf$ yc iam service-account create --name sa-hw-9-04
done (1s)
id: aje4tef4imlt4onoq0l9
folder_id: b1gdgmsgdk7cgpl8l8i5
created_at: "2024-10-03T21:39:36.043694096Z"
name: sa-hw-9-04

#### 4 Для созданного сервисного аккаунта создадим авторизованный ключ для управления каталогом
user@debian:~/terraform-project/HW-9-04-tf$ yc iam key create --service-account-name sa-hw-9-04 --folder-name hw-9-04-r --output ./yc-sa-key-hw-9-04.json
id: ajep0g9jdr33mdf8cnih
service_account_id: ajekt7rfg5l29ldb7dho
created_at: "2024-10-03T21:40:55.193008127Z"
key_algorithm: RSA_2048

## 5 Для конфигурации профиля CLI yc profile-7-03-task-1 
## укажем созданный авторизованный ключ сервсного аккаунта sa-tf-7-03-task-1 :
$ yc config set service-account-key ./yc-sa-key-hw-9-04.json



в облаке 
folder: hw-9-04 
folder-id: b1gdgmsgdk7cgpl8l8i5
service-account: sa-hw-9-04 
service-account-id: ajekt7rfg5l29ldb7dho  

yc iam create-token
yc config set cloud-id b1gat3mr49cc9tpvs9vo # облако cloud-a-debian
yc config set folder-id b1gdgmsgdk7cgpl8l8i5 # каталог terraform-1, в котором сервис-аккаунт terraform-sa, в этом каталоге имеет роли viewer editor 


export YC_TOKEN=$(yc iam create-token)
export YC_CLOUD_ID=$(yc config get cloud-id)
export YC_FOLDER_ID=$(yc config get folder-id)

# IAM-token
t1.9euelZqMzs7IyJuTl8qcl4mVkJiUlu3rnpWay4uamcuWkpOLy5CRkI7Pk8bl8_dOMXlH-e9PXRpR_N3z9w5gdkf5709dGlH8zef1656VmpuNzMmXypeKi5COmJOSnovP7_zN5_XrnpWamprMy5LNjsjLlo3KjpTHnZnv_cXrnpWam43MyZfKl4qLkI6Yk5Kei88.Mj1SKnreESzI74XN0Vc4VwMVcqKwepocwWbo96VvFQR2m5HGBn9LoFNqRLDN0Lll6lwS6O_geMcMUViZLAp8Cw


### ВЫВОД после terraform apply:

Outputs:

lb-9-04-ip = toset([
  {
    "external_address_spec" = toset([
      {
        "address" = "84.201.147.190"
        "ip_version" = "ipv4"
      },
    ])
    "internal_address_spec" = toset([])
    "name" = "lb-9-04"
    "port" = 80
    "protocol" = "tcp"
    "target_port" = 80
  },
])
vm-ips = tomap({
  "0" = true
  "1" = true
})